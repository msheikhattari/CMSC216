/* Student ID: 117018387
 * Name: Mohammad Sheikhattari */

#include <string.h>
#include <sys/wait.h>
#include <sysexits.h>
#include <stdlib.h>
#include <fcntl.h>
#include <err.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <errno.h>
#include "command.h"
#include "executor.h"

#define FILE_PERMISSIONS 0664

/*
static void print_tree(struct tree *t);
*/

int execute_aux(struct tree *t, int input_fd, int output_fd) {
	pid_t pid, child_p1, child_p2;
	int status, fd_in, fd_out, pipe_fd[2];

	if(t->conjunction == NONE) {
		if(strcmp(t->argv[0], "cd") == 0) {
			if(t->argv[1] == NULL) {
				chdir(getenv("HOME"));	
			}else {
				if(chdir(t->argv[1]) == -1) {
					perror(t->argv[1]);
					return 1;
				}
			}
			return 0;
		}
		if(strcmp(t->argv[0], "exit") == 0) {
			exit(0);
		}
		/* Forking */
		if((pid = fork()) < 0) {
			perror("fork");
		}
		/* Parent */
		if(pid) {
			wait(&status);
			return WEXITSTATUS(status);

		/* Child code */
		}else {
			/* Input redirection */
			if(t->input != NULL) {
				if((fd_in = open(t->input, O_RDONLY)) < 0) {
					perror("open");
				}
				if(dup2(fd_in, STDIN_FILENO) < 0) {
					perror("dup2");
				}
				if(close(fd_in) < 0) {
					perror("close");
				}
			}
			if(t->output != NULL) {
				if((fd_out = open(t->output, O_WRONLY | O_CREAT | O_TRUNC
									 , FILE_PERMISSIONS)) < 0) {
					perror("open");
				}
				if(dup2(fd_out, STDOUT_FILENO) < 0) {
					perror("dup2");
				}
				if(close(fd_out) < 0) {
					perror("close");
				}
			}

			execvp(t->argv[0], t->argv);
			fprintf(stderr, "Failed to execute %s\n", t->argv[0]);
			exit(1);
		}		
	}else if(t->conjunction == AND) {
		if(execute_aux(t->left, input_fd, output_fd) == 0) {
			return execute_aux(t->right, input_fd, output_fd);
		}else {
			return execute_aux(t->left, input_fd, output_fd);
		}
	}else if(t->conjunction == PIPE) {
		pipe(pipe_fd);
		
		if((child_p1 = fork()) < 0) {
			perror("fork");
		}

		/* Left subtree taken care of by child_p1 */
		if(!child_p1) {
			if(close(pipe_fd[0]) < 0) {
				perror("close");
			}
		
			if(t->left->output != NULL) {
				printf("Ambiguous output redirect.\n");
				exit(1);
			}

			if(t->input != NULL) {	
				if((fd_in = open(t->input, O_RDONLY)) < 0) {
					perror("open");
				}
				if(dup2(fd_in, STDIN_FILENO) < 0) {
					perror("dup2");
				}
				if(close(fd_in) < 0) {
					perror("close");
				}
			}else {
				if(dup2(input_fd, STDIN_FILENO) < 0) {
					perror("dup2");
				}
			}
			if(dup2(pipe_fd[1], STDOUT_FILENO) < 0) {
				perror("dup2");
			}
			if(close(pipe_fd[1]) < 0) {
				perror("close");
			}
			exit(execute_aux(t->left, input_fd, output_fd));
		}
		
		if((child_p2 = fork()) < 0) {
			perror("fork");
		}

		/* Right subtree taken care of by child_p2 */
		if(!child_p2) {			
			if(close(pipe_fd[1]) < 0) {
				perror("close");
			}
		
			if(t->right->input != NULL) {
				printf("Ambiguous input redirect.\n");
				exit(1);
			}

			if(t->output != NULL) {
				if((fd_out = open(t->output, O_RDONLY)) < 0) {
					perror("open");
				}
				if(dup2(fd_out, STDOUT_FILENO) < 0) {
					perror("dup2");
				}
				if(close(fd_out) < 0) {
					perror("close");
				}
			}else {
				if(dup2(output_fd, STDIN_FILENO) < 0) {
					perror("dup2");
				}
			}
			if(dup2(pipe_fd[0], STDIN_FILENO) < 0) {
				perror("dup2");
			}
			if(close(pipe_fd[0]) < 0) {
				perror("close");
			}
			exit(execute_aux(t->right, input_fd, output_fd));
		}

		/* Parent */
		if(close(pipe_fd[0]) < 0 || close(pipe_fd[1]) < 0) {
				perror("close");
		}	
	
		wait(NULL);
		wait(NULL);

	}else if(t->conjunction == SUBSHELL) {
		/* Forking */
		if((pid = fork()) < 0) {
			perror("fork");
		}
		/* Parent */
		if(pid) {
			wait(&status);
			return WEXITSTATUS(status);

		/* Child code */
		}else {
			/* Input redirection */
			if(t->input != NULL) {
				if((fd_in = open(t->input, O_RDONLY)) < 0) {
					perror("open");
				}else {
					input_fd = fd_in;
				}
			
				if(dup2(input_fd, STDIN_FILENO) < 0) {
					perror("dup2");
				}
				if(close(input_fd) < 0) {
					perror("close");
				}
			}
			if(t->output != NULL) {
				if((fd_out = open(t->output, O_WRONLY | O_CREAT | 
								  O_TRUNC, FILE_PERMISSIONS)) < 0) {
					perror("open");
				}else {
					output_fd = fd_out;
				}
				if(dup2(output_fd, STDOUT_FILENO) < 0) {
					perror("dup2");
				}
				if(close(output_fd) < 0) {
					perror("close");
				}
			}
			exit(execute_aux(t->left, input_fd, output_fd));
		}		
		
	}
	return 0;
}

int execute(struct tree *t) {	
    return execute_aux(t, STDIN_FILENO, STDOUT_FILENO);
}

/*
static void print_tree(struct tree *t) {
   if (t != NULL) {
      print_tree(t->left);

      if (t->conjunction == NONE) {
         printf("NONE: %s, ", t->argv[0]);
      } else {
         printf("%s, ", conj[t->conjunction]);
      }
      printf("IR: %s, ", t->input);
      printf("OR: %s\n", t->output);

      print_tree(t->right);
   }
}
*/
