#include <stdio.h>
#include <string.h>
#include "document.h"

int paragraph_space(const Document *doc, char data[][MAX_STR_SIZE + 1],
				    const int data_lines);

int line_space(const Document *doc, char data[][MAX_STR_SIZE + 1],
               const int data_lines);

int remove_text_line(Document *doc, const char *target,						                     const int paragraph, const int line);

int replace_text_line(Document *doc, const char *target,
					  const char *replacement, const int paragraph,
					  const int line);

int highlight_text_line(Document *doc, const char *target,
	                  const int paragraph, const int line);

int main() {
   Document doc;
   const char *doc_name = "Exercise Description";
   int k = 1, data_lines = 0, paragraph_number, line_number;
   char data[40][MAX_STR_SIZE + 1] = {{0}, {0}, {0}, {'a', 'b', 'c', 'd'}, {0}, {33}, {33},
   {0}, {10}, {33}, {33}, {33}, {33}, {33}, {33}, {33}, {33}, {33}, {33}, 
   {33}, {33}, {33}, {33}, {33}, {33}, {33}};

   init_document(&doc, doc_name);

   /* Adding paragraph */
   /*paragraph_number = 0;
   add_paragraph_after(&doc, paragraph_number);
*/
   /* Adding lines to paragraph */
  /* paragraph_number = 1;
*/
   /* First line */
  /* line_number = 0;
   add_line_after(&doc, paragraph_number, line_number, "First Paragraph, First line");
*/
   /* Additional lines */
  /* add_line_after(&doc, paragraph_number, line_number + 1, "First Paragraph, Second line");
   add_line_after(&doc, paragraph_number, line_number + 2, "First Paragraph, Third line");

	add_paragraph_after(&doc, paragraph_number);

	paragraph_number = 2;

	add_line_after(&doc, paragraph_number, line_number,	"Second Paragraph, First line");
	add_line_after(&doc, paragraph_number, line_number + 1, "Second Paragraph, Second line");
 	add_line_after(&doc, paragraph_number, line_number + 2, "Second Paragraph, Third line");

   print_document(&doc);
*/   /*get_number_lines_paragraph(&doc, 1, &k);
   printf("%d", k);*/

  /* add_paragraph_after(&doc, 1);
  
   add_line_after(&doc, 2, 0, "Inserted after paragraph 1.");

   remove_line(&doc, 2, 1);
   printf("\n%d\n", doc.number_of_paragraphs);

 */  replace_text(&doc, "ne", "");
   load_document(&doc, data, 3);

   print_document(&doc);
   get_number_lines_paragraph(&doc, 2, &k);
   printf("%d", k);  

   return 0;
}
