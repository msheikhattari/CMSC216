/* Name: Mohammad Sheikhattari
 * UID: 117018387 
 * Directory ID: msheikha */

#include <stdio.h>
#include <assert.h>
#include <math.h>

#define MAX_SIZE 50
#define MAX_INT 2147483647

/* Processes all of the assignment information. The scores, weights, and 
 * days late associated with each assignment are stored in the scores,
 * weights, and days array, respectively. Each entry of the arrays
 * corresponds to that assignment number (eg. the first element ->
 * assignment number 1). */
static int process_assignments (const int num_assignments, int scores[], 
				int weights[], int days[]) {
    int i, assignment_num = 0;

    /* Array names used for index assignment for practice with memory .*/
    for (i = 0; i < num_assignments; i++) {
	scanf (" %d%*c", &assignment_num);
	assignment_num -= 1;
        scanf (" %d%*c %d%*c %d%*c", scores + assignment_num, weights + 
              assignment_num, days + assignment_num);
    }
    return 1;
}

/* Computes the numeric score by first dropping the "lowest value"
 * assignments, then taking into account days late and point penalty per day
 * late, and the weights associated with the assignments. Assignment value
 * is determined by multiplying each assignment score by its weight. */
static float compute_score (const int num_assignments, const int num_drop,
			    const int penalty, const int scores[],
		            const int weights[], const int days[]) {
    int min_value = MAX_INT, removed = 0, i, total_weight_left = 0, 
        sorted_values[MAX_SIZE] = {0};
    double score = 0;
    
    /* Assignment values are first stored. */
    for (i = 0; i < num_assignments; i++) {
	sorted_values[i] = scores[i] * weights[i];
    }

    /* Removes the lowest value assignments. A minimum value is first
     * stored, then the program loops back through the assignment_values
     * until the minimum value is first encountered. The value at that index
     * is set to -1 as an identifying marker that it shouldn't be included
     * in the score. */ 
    while (removed < num_drop) {
	for (i = 0; i < num_assignments; i++) {
            if (sorted_values[i] < min_value && sorted_values[i] != -1) {
                min_value = sorted_values[i];
            }
        }

	for (i = 0; i < num_assignments; i++) {
	    if (sorted_values[i] == min_value) {
	        sorted_values[i] = -1;
		removed++;
		min_value = MAX_INT;
		i = num_assignments - 1;
	    }
	}
    }

    /* For all assignment values that haven't been marked as excluded, a
     * point penalty is applied per day late, taking into account the
     * assignment's weight. If after applying the penalty a negative 
     * score results, its value is floored to 0. */
    for (i = 0; i < num_assignments; i++) {
	if (sorted_values[i] != -1) {
	    sorted_values[i] -= penalty * weights[i] * days[i];
	    if (sorted_values[i] < 0) {
		sorted_values[i] = 0;
	    }
	    	       
	}
    }

    /* Preliminary score found by adding up all of the assignment values
     * not to be excluded, and after deducting the point penalty. The 
     * weights remaining are also stored. */ 
    for (i = 0; i < num_assignments; i++) {
	if (sorted_values[i] != -1) {
	    score += sorted_values[i];
	    total_weight_left += weights[i];
	}
    }   

    /* Finally the score is normalized by dividing out the remaining
     * weights. */
    score /= total_weight_left;

    return score;
}

/* Helper function for calculating the mean of assignment scores, after
 * taking into account the point penalty.*/
static double calculate_mean (const int num_assignments, const int penalty,
			      const int scores[], const int days[]) {
    int i;
    double mean = 0, temp_score;

    for (i = 0; i < num_assignments; i++) {
	temp_score = scores[i] - (penalty * days[i]);

	if (temp_score < 0) {
	    temp_score = 0;
	}
	
	mean += temp_score;
    }

    return mean / num_assignments;
}

/* Helper function for calculating the standard deviation of assignment
 * scores,
 * after taking into account the point penalty. */
static double calculate_stdev (const int num_assignments, const int penalty,
			       const int scores[], const int days[]) {
    int i;
    double mean = calculate_mean (num_assignments, penalty, scores, days),
	   differences_squared = 0, temp_score; 
    
    for (i = 0; i < num_assignments; i++) {
	temp_score = scores[i] - (penalty * days[i]);

	if (temp_score < 0) {
	    temp_score = 0;
	}

	differences_squared += pow (temp_score - mean, 2.0);
    }

    return sqrt (differences_squared / num_assignments);
}

/* Helper function for determining if the total weights sum to 100. 1 is 
 * returned if they do, and 0 if not.*/
static int valid_weights (const int num_assignments, const int weights[]) {
    int i, weights_sum = 0;

    for (i = 0; i < num_assignments; i++) {
        weights_sum += weights[i];
    }

    if (weights_sum != 100) {
	return 0;
    }

    return 1;
}

/* Processes information about class assignments and computes an overall
 * numeric score. Information about the score, points penalty per day late,
 * number of assignments dropped, and assignment info provided (sorted by
 * assignment number) are displayed to the user. Optionally, a mean and
 * standard deviation are also provided. */
int main () {
    int i, num_assignments, penalty, num_drop, scores[MAX_SIZE] = {0},
	weights[MAX_SIZE] = {0}, days[MAX_SIZE] = {0};
    char gen_stat;

    /* Assignment info is read from the user and stored. */
    scanf (" %d %d %c\n %d", &penalty, &num_drop, &gen_stat, 
	   &num_assignments);
    process_assignments (num_assignments, scores, weights, days);

    /* Check that the total weights sum to 100. If not, an error message is
     * outputted and the program is terminated. */
    if (valid_weights (num_assignments, weights) == 0) {
	printf ("%s", "ERROR: Invalid values provided\n");
	return 0;
    }
    
    /* Outputs numeric score, points penalty per day late, number of 
     * assignments dropped, and preliminary assignment info format. */
    printf ("%s%5.4f\n", "Numeric Score: ", compute_score (num_assignments,
	    num_drop, penalty, scores, weights, days));
    printf ("%s%d\n", "Points Penalty Per Day Late: ", penalty);
    printf ("%s%d\n", "Number of Assignments Dropped: ", num_drop);
    printf ("%s\n", "Values Provided:");
    printf ("%s\n", "Assignment, Score, Weight, Days Late"); 
    
    /* Assignment info is outputted for every assignment. */
    for (i = 0; i < num_assignments; i++) {
	printf ("%d%c %d%c %d%c %d\n", i + 1, 44, scores[i], 44, 
                weights[i], 44, days[i]); 
    }

    /* If user selected to have statistical info included, then this appears
     * in output. */
    if (gen_stat == 89 || gen_stat == 121) {
	printf ("%s%5.4f%c %s%5.4f\n", "Mean: ",
		calculate_mean (num_assignments, penalty, scores, days),
		44, "Standard Deviation: ",
		calculate_stdev (num_assignments, penalty, scores, days));
    }
 
    return 1;
}
