/* Name: Mohammad Sheikhattari
 * UID: 117018387 
 * Directory ID: msheikha */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "event.h"
#include "calendar.h"
#include "my_memory_checker_216.h"

/*****************************************************/
/* In this file you will provide tests for your      */
/* calendar application.  Each test should be named  */
/* test1(), test2(), etc. Each test must have a      */
/* brief description of what it is testing (this     */
/* description is important).                        */
/*                                                   */
/* You can tell whether any test failed if after     */
/* executing the students tests, you executed        */
/* "echo $?" on the command line and you get a value */
/* other than 0.  "echo $?" prints the status of     */
/* the last command executed by the shell.           */ 
/*                                                   */
/* Notice that main just calls test1(), test2(), etc.*/
/* and once one fails, the program eventually        */
/* return EXIT_FAILURE; otherwise EXIT_SUCCESS will  */
/* be returned.                                      */
/*****************************************************/

static int comp_minutes(const void *ptr1, const void *ptr2) {
   return ((Event *)ptr1)->duration_minutes - ((Event *)ptr2)->duration_minutes;
}

/* Pulled struct and static methods below from public05.c for testing 
 * purposes. */
typedef struct task_info {
  double cost;
  char *prog_language;
} Task_info;

static int comp_name(const void *ptr1, const void *ptr2) {
   return strcmp(((Event *)ptr1)->name, ((Event *)ptr2)->name);
}

static Task_info *create_task_info(double cost, const char *prog_language) {
    Task_info *task_info = malloc(sizeof(Task_info));

    if (task_info) {
        task_info->prog_language = malloc(strlen(prog_language) + 1);
        if (task_info->prog_language) {
            task_info->cost = cost;
            strcpy(task_info->prog_language, prog_language);
            return task_info;
        }
    }

    return NULL;
}

static void free_task_info(void *ptr) {
    Task_info *task_info = (Task_info *)ptr;

    free(task_info->prog_language);
    free(task_info);
}

/* This test checks whether the init_calendar function works as expected. 
 * All failure checks are tested as well. */
static int test1() {
    int days = 7;
    Calendar *calendar;

    if(init_calendar("Spr", days, comp_minutes, NULL, &calendar)
		== SUCCESS) {
        printf("Total events: %d\n", calendar->total_events);
	    /* Failure checks for initialization. */
	    if (init_calendar(NULL, days, comp_minutes, NULL, &calendar)
		    == SUCCESS || init_calendar("Name", days, comp_minutes, NULL,
			NULL) == SUCCESS || init_calendar("Name", 0, NULL, NULL,
			&calendar) == SUCCESS) {
	        return FAILURE;
        }
	    destroy_calendar(calendar);

	    return SUCCESS;
   }
   return FAILURE;
}

/* This test checks whether the print_calendar function works as expected
 * The following cases were tested: 
 * 1. Printing a calendar with and without events
 * 2. Printing a calendar with print_all both set to true and false
 * 3. Printing a calendar both to stdout and a file
 * Additionally, all failure checks were tested. */
static int test2() {
    int days = 7;
    Calendar *calendar;
    FILE *file = fopen("output.txt", "w");

    /* Checking edge cases for printing. */
    if(init_calendar("Spr", days, comp_minutes, NULL, &calendar) 
	    == SUCCESS) {
        print_calendar(calendar, stdout, 1);
	    print_calendar(calendar, stdout, 0);
	    add_event(calendar, "event1", 800, 20, NULL, 1);
        print_calendar(calendar, file, 1);
	
	    /* Failure checks for initialization. */
	    if(init_calendar(NULL, days, comp_minutes, NULL, &calendar) 
		   == SUCCESS || init_calendar("Name", days, comp_minutes, NULL, 
		   NULL) == SUCCESS || init_calendar("Name", 0, NULL, NULL, 
		   &calendar) == SUCCESS) {
	        return FAILURE;
        }
		
	    /* Failure checks for printing. */
	    if(print_calendar(calendar, NULL, 1) == SUCCESS || 
	        print_calendar(NULL, stdout, 1) == SUCCESS) {
	        return FAILURE;
        }
	    destroy_calendar(calendar);

        return SUCCESS;
    }
    
   return FAILURE;
}

/* This test checks whether the add_event function works as expected. 
 * The following cases were tested:
 * 1. Adding first event
 * 2. Adding event larger than any in list
 * 3. Adding event of same rank of another event in list
 * 4. Adding event with same name as another already in the list to same day
 * 5. Adding event with same name as another in the list to a different day
 * 6. Adding event to different day
 * 7. Adding event in the middle of list
 * Additionally, all failure checks are tested. */
static int test3() {
    int days = 5;    
    Calendar *calendar, *calendar_no_func;

    if(init_calendar("Newb", days, comp_minutes, NULL, &calendar)
	   == SUCCESS) {
        init_calendar("Newb", days, NULL, NULL, &calendar_no_func);
      
	    /* Checking edge cases for adding events. */
	    add_event(calendar, "event1", 800, 20, NULL, 1);
	    add_event(calendar, "event2", 800, 25, NULL, 1);
	    add_event(calendar, "event3", 800, 25, &days, 1);
        add_event(calendar, "event2", 800, 30, NULL, 1);
	    add_event(calendar, "event2", 800, 30, NULL, 3);
	    add_event(calendar, "event4", 2400, 30, NULL, 5);
	    add_event(calendar, "event5", 0, 22, NULL, 1);

	    /* Failure checks. */
	    if(add_event(NULL, "a", 800, 20, NULL, 1) == SUCCESS ||
		   add_event(calendar, NULL, 800, 20, NULL, 1) == SUCCESS ||
		   add_event(calendar, "a", -1, 20, NULL, 1) == SUCCESS ||
		   add_event(calendar, "a", 2401, 20, NULL, 1) == SUCCESS ||
		   add_event(calendar, "a", 800, 0, NULL, 1) == SUCCESS ||
		   add_event(calendar, "a", 800, 20, NULL, 0) == SUCCESS ||
		   add_event(calendar, "a", 800, 20, NULL, 6) == SUCCESS ||
		   add_event(calendar_no_func, "a", 800, 20, NULL, 1) == SUCCESS) {
            return FAILURE;
	    }

	    print_calendar(calendar, stdout, 1);
	    if(calendar->total_events == 5) {
 	        destroy_calendar(calendar);
			destroy_calendar(calendar_no_func);

 	        return SUCCESS;
	    }
    }

    return FAILURE;
}

/* This test checks whether the find_event function works as expected. 
 * The following cases were tested: 
 * 1. Searching for events both in and not in list
 * 2. Using both NULL and not NULL event parameter 
 * Additionally, all failure checks are tested. */
static int test4() {
	int days = 7;
	Calendar *calendar;
	Event *event;
	/* Loading up calendar. */
	init_calendar("Newb", days, comp_minutes, NULL, &calendar);
	add_event(calendar, "event1", 800, 20, NULL, 1);
	add_event(calendar, "event2", 500, 25, NULL, 1);
	add_event(calendar, "event3", 100, 25, NULL, 1);
	add_event(calendar, "event4", 2400, 30, NULL, 5);
	add_event(calendar, "event5", 0, 22, NULL, 1);
    
	/* Failure checks for find_event. */
    if(find_event(NULL, "event3", &event) == SUCCESS ||
	   find_event(calendar, NULL, &event) == SUCCESS ||
	   find_event(calendar, "event", &event) == SUCCESS) {
		return FAILURE;
	}

	/* Searching for event in list. */
	find_event(calendar, "event3", &event);
	if(event->start_time != 100) {
		return FAILURE;
	}
	/* Searching for event not in list, searching with null event. */
	if(find_event(calendar, "event", &event) != FAILURE ||
	   find_event(calendar, "event3", NULL) != SUCCESS) {
		return FAILURE;
	}
	destroy_calendar(calendar);

	return SUCCESS;
}

/* This test checks whether the find_event_in_day function works as expected
 * The following cases were tested: 
 * 1. Searching for events both in and not in list 
 * 2. Searching for event in list but not a particular day 
 * 3. Using both NULL and not NULL event parameter 
 * Additionally, all failure checks are tested. */
static int test5() {
	int days = 7;
	Calendar *calendar;
	Event *event;
	/* Loading up calendar. */
	init_calendar("Newb", days, comp_minutes, NULL, &calendar);
	add_event(calendar, "event1", 800, 20, NULL, 1);
	add_event(calendar, "event2", 500, 25, NULL, 1);
	add_event(calendar, "event3", 100, 25, NULL, 1);
	add_event(calendar, "event4", 2400, 30, NULL, 5);
	add_event(calendar, "event5", 0, 22, NULL, 1);
    
	/* Failure checks for find_event_in_day. */
	if(find_event_in_day(NULL, "event3", 1, &event) == SUCCESS ||
	   find_event_in_day(calendar, NULL, 1, &event) == SUCCESS ||
	   find_event_in_day(calendar, "event3", 0, &event) == SUCCESS ||
	   find_event_in_day(calendar, "event3", 8, &event) == SUCCESS ||
	   find_event_in_day(calendar, "event", 1, &event) == SUCCESS) {
		return FAILURE;
	}

	/* Searching for event in list on particular day. */
	find_event_in_day(calendar, "event2", 1, &event);
	if(event->start_time != 500) {
		return FAILURE;
	}

	/* Searching for event not in list, searching with null event, 
	 * searching for event in list but not that day. */
	if(find_event_in_day(calendar, "event", 1, &event) != FAILURE ||
	   find_event_in_day(calendar, "event1", 1, NULL) != SUCCESS ||
	   find_event_in_day(calendar, "event1", 5, &event) != FAILURE) {
		return FAILURE;
	}
    destroy_calendar(calendar);

	return SUCCESS;
}

/* This test checks whether the remove_event function works as expected.
 * The following cases were tested: 
 * 1. Removing an event in the middle of the list
 * 2. Removing an event at the end of the list
 * 3. Removing an event at the head of the list
 * 4. Removing an event that is the only element of a list
 * Additionally, all FAILURE checks were tested. */
static int test6() {
    int days = 5;    
    Calendar *calendar;

    if(init_calendar("Newb", days, comp_minutes, NULL, &calendar)
	   == SUCCESS) {
        /* Loading up calendar and printing its initial state. */
	    add_event(calendar, "event1", 800, 20, NULL, 1);
	    add_event(calendar, "event2", 800, 25, NULL, 1);
	    add_event(calendar, "event3", 800, 25, &days, 1);
	    add_event(calendar, "event4", 2400, 30, NULL, 5);
	    add_event(calendar, "event5", 0, 22, NULL, 1);

	    print_calendar(calendar, stdout, 1);

	    /* Failure checks. */
	    if(remove_event(NULL, "event1") == SUCCESS ||
	  	   remove_event(calendar, NULL) == SUCCESS ||
		   remove_event(calendar, "event") == SUCCESS) {
	        return FAILURE;
	    }

	    /* Testing edge cases for removing events and checking the state of 
	     * the calendar after. */
        remove_event(calendar, "event5");
	    remove_event(calendar, "event2");
	    remove_event(calendar, "event1");
	    remove_event(calendar, "event4");

	    print_calendar(calendar, stdout, 1);

	    if(calendar->total_events != 1) {
	        return FAILURE;
	    }	  
        destroy_calendar(calendar);

        return SUCCESS;
    }
    return FAILURE;
}

/* This test checks whether the get_event_info function works as expected. 
 * It was used in conjunction with an info struct and free_info_func defined
 * in public05.c, and it was used both on an event in and not in the 
 * calendar. Additionally, the remove_event function was tested in order to
 * see if the info of a removed event was correctly cleared. */
static int test7() {
    int days = 5;    
    Calendar *calendar;
    Task_info *info, *returned_info = NULL;


    if(init_calendar("Newb", days, comp_minutes, free_task_info, &calendar)
   	   == SUCCESS) {
      
	    /* Loading up calendar. */
   	    info = create_task_info(10000, "JUnit");
	    add_event(calendar, "event1", 800, 20, info, 1);
	  
	    /* Confirming what happens if we call the function using a name not
	     * in the calendar. */
	    if(get_event_info(calendar, "event") != NULL) {
	        return FAILURE;
	    }

	    /* Checking to see if the info was successfully returned. */
	    if ((returned_info = get_event_info(calendar, "event1")) != NULL) {
	        printf("Info cost: %f\n", returned_info->cost);
	    }else {
	        printf("Mission failed: better luck next time\n");
	    } 
	    remove_event(calendar, "event1");
        destroy_calendar(calendar);

        return SUCCESS;
    }
    return FAILURE;
}

/* This test checks the clear_calendar function and sees if every event
 * was correctly removed. Additionally the failure check is tested. */
static int test8() {
    int days = 5;    
    Calendar *calendar;

    if(init_calendar("Newb", days, comp_minutes, NULL, &calendar) 
	   == SUCCESS) {
        /* Loading up calendar and printing its initial state. */
	    add_event(calendar, "event1", 800, 20, NULL, 1);
	    add_event(calendar, "event2", 800, 25, NULL, 1);
	    add_event(calendar, "event3", 800, 25, NULL, 1);
	    add_event(calendar, "event4", 2400, 30, NULL, 5);
	    add_event(calendar, "event5", 0, 22, NULL, 1);

	    print_calendar(calendar, stdout, 1);

	    clear_calendar(calendar);

	    print_calendar(calendar, stdout, 1);
 
 		/* FAILURE checks. */
   	    if(clear_calendar(NULL) != FAILURE) {
	        return FAILURE;
	    }
        destroy_calendar(calendar);

        return SUCCESS;
    }
    return FAILURE;
}

/* This test checks the clear_day function and sees if every event in that
 * day was correctly removed. Additionally, the failure checks were tested*/
static int test9() {
    int days = 5;    
    Calendar *calendar;

    if(init_calendar("Newb", days, comp_minutes, NULL, &calendar) 
	   == SUCCESS) {
        /* Loading up calendar and printing its initial state. */
	    add_event(calendar, "event1", 800, 20, NULL, 1);
	    add_event(calendar, "event2", 800, 25, NULL, 1);
	    add_event(calendar, "event3", 800, 25, NULL, 1);
	    add_event(calendar, "event4", 2400, 30, NULL, 5);
	    add_event(calendar, "event5", 0, 22, NULL, 1);

	    print_calendar(calendar, stdout, 1);

	    clear_day(calendar, 1);

	    print_calendar(calendar, stdout, 1);
   		
		/* FAILURE checks. */
   	    if(clear_day(NULL, 1) != FAILURE ||
		   clear_day(calendar, 0) != FAILURE ||
		   clear_day(calendar, 6) != FAILURE) {
	        return FAILURE;
	    }
        destroy_calendar(calendar);

        return SUCCESS;
    }
    return FAILURE;
}

/* This test checks the destroy_calendar function and sees if every event in
 * the calendar was correctly removed and all memory was deallocated with 
 * no memory leaks. Additionally, the failure checks were tested. */
static int test10() {
    int days = 5;    
    Calendar *calendar;

    if(init_calendar("Newb", days, comp_minutes, NULL, &calendar)
	   == SUCCESS){
        /* Loading up calendar and printing its initial state. */
	    add_event(calendar, "event1", 800, 20, NULL, 1);
	    add_event(calendar, "event2", 800, 25, NULL, 1);
	    add_event(calendar, "event3", 800, 25, NULL, 1);
	    add_event(calendar, "event4", 2400, 30, NULL, 5);
	    add_event(calendar, "event5", 0, 22, NULL, 1);

	    print_calendar(calendar, stdout, 1);
	    destroy_calendar(calendar);

	    /* Failure check. */
	    if(destroy_calendar(NULL) != FAILURE) {
	        return FAILURE;
	    } 

	    return SUCCESS;
    }
    return FAILURE;
}

int main() {
    int result = SUCCESS;

    /***** Starting memory checking *****/
    start_memory_check();
    /***** Starting memory checking *****/

    if(test1() == FAILURE) {
        result = FAILURE;
    }
    if(test2() == FAILURE) {
        result = FAILURE;
    }
    if(test3() == FAILURE) {
        result = FAILURE;
    }
    if(test4() == FAILURE) {
        result = FAILURE;
    }
    if(test5() == FAILURE) {
        result = FAILURE;
    }
    if(test6() == FAILURE) {
        result = FAILURE;
    }
    if(test7() == FAILURE) {
        result = FAILURE;
    }
    if(test8() == FAILURE) {
        result = FAILURE;
    }
    if(test9() == FAILURE) {
        result = FAILURE;
    }
    if(test10() == FAILURE) {
        result = FAILURE;
    }
    /****** Gathering memory checking info *****/
    stop_memory_check();
    /****** Gathering memory checking info *****/
   
    if(result == FAILURE) {
        exit(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
}
