/* Name: Mohammad Sheikhattari
 * UID: 117018387
 * Directory ID: msheikha */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "event.h"
#include "calendar.h"
#include "my_memory_checker_216.h"

/* Helper function used to determine if an event with a given name exists
 * in a provided array of event linked lists. If it does, FAILURE is 
 * returned and that event is returned, otherwise SUCCESS is. If day is
 * non-negative, same_name will only return FAILURE if an event with the
 * specified name is found in that particular day. */
static int same_name(const char *name, Event **events, int days, int day) {
	Event *curr_event;
	int i;

	for(i = 0; i < days; i++) {
		curr_event = *(events + i);
		while(curr_event != NULL) {
			if(strcmp(curr_event->name, name) == 0) {
				if(day > 0 && day != i + 1) {
					return SUCCESS;
				}
				return FAILURE;
			}
			curr_event = curr_event->next;
		}
	}
	return SUCCESS;
}

/* Recursive helper function for clear_calendar, clear_day, destroy_calendar
   which keeps removing the head until the head is null. */
static void remove_all_aux(Calendar *calendar, Event **head) {
	Event *cur_event;

	if(*head != NULL) {
		cur_event = *head;
		*head = cur_event->next;
	
	/* Memory associated with the event is freed. The info of the event is
	 * only freed if the info field and free_info_func are not NULL, but
	 * the name and event itself are always freed. */
		if(calendar->free_info_func != NULL && cur_event->info != NULL) {
			calendar->free_info_func(cur_event->info);
		}
		free(cur_event->name);
		free(cur_event);
		calendar->total_events--;

		remove_all_aux(calendar, head);
	}
}

/* Initializes a Calendar struct based on the provided parameters. Memory
 * is allocated for the Calendar struct, the name string, and array of 
 * pointers to Event structs. The out-parameter calendar provides access
 * to the new Calendar struct. If calendar and/or name are NULL, days < 1, 
 * or any memory allocation fails the function returns FAILURE, otherwise it
 * returns SUCCESS. */
int init_calendar(const char *name, int days, 
				  int (*comp_func) (const void *ptr1, const void *ptr2),
				  void (*free_info_func) (void *ptr), Calendar **calendar) {
	Calendar *new_calendar;

	/* FAILURE checks and memory allocation. */
	if(calendar == NULL || name == NULL || days < 1 || 
	   (new_calendar = malloc(sizeof(Calendar))) == NULL || 
	   (new_calendar->name = malloc(strlen(name) + 1)) == NULL ||
	   (new_calendar->events = calloc(days, sizeof(Event))) == NULL) {
		return FAILURE;
	}
	
	/* Assignment of given parameters to array, and copying of newly created
	 * calendar to the out-parameter calendar. */
	new_calendar->total_events = 0;
	new_calendar->days = days;
	strcpy(new_calendar->name, name);
	new_calendar->comp_func = comp_func;
	new_calendar->free_info_func = free_info_func;
	
	*calendar = new_calendar;

	return SUCCESS;
}

/* Prints to output_stream the calendar's name, days, and total number of 
 * events if print_all != 0, otherwise this is not printed. Information
 * about each event is printed regardless of the value of print_all. If the
 * calendar or output_stream are NULL the function returns FAILURE, 
 * otherwise SUCCESS is returned. */
int print_calendar(Calendar *calendar, FILE *output_stream, int print_all) {
	int i;
	Event *curr_event;

	/* FAILURE checks. */
	if(calendar == NULL || output_stream == NULL) {
		return FAILURE;
	}

	/* Calendar's name, days, and total number of events printed if
	 * print_all is not false. */
	if(print_all) {
		fprintf(output_stream, "Calendar's Name: \"%s\"\n",
				calendar->name);
		fprintf(output_stream, "Days: %d\n", calendar->days);
		fprintf(output_stream, "Total Events: %d\n\n",
				calendar->total_events);
	}
	/* Events header always printed. */
	fprintf(output_stream, "**** Events ****\n");

	/* Event info is printed if there are events. */
	if(calendar->total_events > 0) {
		for(i = 0; i < calendar->days; i++) {
			fprintf(output_stream, "Day %d\n", i + 1);	
			curr_event = *(calendar->events + i);
			while(curr_event != NULL) {
				fprintf(output_stream, 
				"Event's Name: \"%s\", Start_time: %d, Duration: %d\n", 
				curr_event->name, curr_event->start_time, 
				curr_event->duration_minutes);
				curr_event = curr_event->next;
			}
		}
	}

	/* Making sure to fclose if output stream was a file and not stdout*/
	if(output_stream != stdout) {
		fclose(output_stream);
	}

	return SUCCESS;
}

/* A new event is created based on the specified parameters and added 
 * to the event list of the provided calendar, in an increasing sorted
 * order based on the comparison function of the calendar. If calendar 
 * and/or name are NULL, start time is not between 0 and 2400 (inclusive),
 * duration_minutes <= 0, day is less than 1 or greater than the number
 * of calendar days, an event with the same name already exists in the
 * calendar, there is no comparison function, or any memory allocation fails
 * then the function returns FAILURE. Otherwise SUCCESS is returned. */
int add_event(Calendar *calendar, const char *name, int start_time, 
			  int duration_minutes, void *info, int day) {
	Event *new_event, *curr_event, *prev_event = NULL;

	/* FAILURE checks and memory allocation. */
	if(calendar == NULL || name == NULL || start_time < 0 || 
	   start_time > 2400 || duration_minutes <= 0 || day < 1 ||
	   day > calendar->days || calendar->comp_func == NULL ||
	   same_name(name, calendar->events, calendar->days, -1) == FAILURE || 
	   (new_event = malloc(sizeof(Event))) == NULL || 
	   (new_event->name = malloc(strlen(name) + 1)) == NULL) {
		return FAILURE;
	}

	/* New event is initialized with given parameters. Current event is
	 * set to head of event array index corresponding to day parameter. */
	curr_event = *(calendar->events + day - 1);
	strcpy(new_event->name, name);
	new_event->start_time = start_time;
	new_event->duration_minutes = duration_minutes;
	new_event->info = info;
	
	/* Insertion point is found. Next variable in new event set to the first
	 * event found that is greater than or equal to the current event based 
	 * on the comparison function, or NULL if no such event is found. */
	while(curr_event != NULL && 
		  calendar->comp_func(new_event, curr_event) > 0) {
		  prev_event = curr_event;
		  curr_event = curr_event->next;
	}
	new_event->next = curr_event;
	/* If adding to head, set new head to be the newly created event. */
	if(prev_event == NULL) {
		*(calendar->events + day - 1) = new_event;
	/* If not adding to head, put the new event in front of the last smaller
	 * event in the list. */
	}else {
		prev_event->next = new_event;
	}
	calendar->total_events++;

	return SUCCESS;
}

/* A pointer to the event with the specified name is returned via the 
 * out-parameter event if an event with that name is found and that 
 * parameter is not NULL, and SUCCESS is returned if an event with that name
 * is found in the list. FAILURE is returned if no event with the specified
 * name is found in the list, or if calendar and/or name are NULL. */
int find_event(Calendar *calendar, const char *name, Event **event) {
	Event *curr_event;
	int i;
	
	/* FAILURE checks. */
	if(calendar == NULL || name == NULL || same_name(name, calendar->events,
	   calendar->days, -1) == SUCCESS) {
		return FAILURE;
	}

	/* Found event is passed via out-parameter event if it's not NULL. */
	if(event != NULL) {
		for(i = 0; i < calendar->days; i++) {
			curr_event = *(calendar->events + i);
			while(curr_event != NULL) {
				if(strcmp(curr_event->name, name) == 0) {
					*event = curr_event;
					return SUCCESS;
				}
				curr_event = curr_event->next;
			}
		}
	}

	return SUCCESS;
}

/* A pointer to the event with the specified name is returned via the 
 * out-parameter event if an event is found in the list on that day and if 
 * that parameter is not NULL, and SUCCESS is returned if an event with that
 * name is found in the list. FAILURE is returned if no event with the
 * specified name is found in the list, if the calendar and/or name are NULL
 * or if the day parameter is not between 1 and calendar days (inclusive) */
int find_event_in_day(Calendar *calendar, const char *name, int day,
					  Event **event) {
	Event *curr_event;

	/* FAILURE checks. */
	if(calendar == NULL || name == NULL || day < 1 || day > calendar->days
	 || same_name(name, calendar->events, calendar->days, day) == SUCCESS) {
		return FAILURE;
	}

	/* Found event is passed via out-parameter event if it's not NULL. */
	if(event != NULL) {
		curr_event = *(calendar->events + day - 1);
		while(curr_event != NULL) {
			if(strcmp(curr_event->name, name) == 0) {
				*event = curr_event;
			}
			curr_event = curr_event->next;
		}
	}

	return SUCCESS;
}

/* If an event with the specified name is present in the calendar, it is
 * removed, all memory associated with the event is freed, and SUCCESS is
 * returned. If the calendar has a free_info_func and the event has info,
 * the event's info is also freed. FAILURE is returned if calendar or name
 * are NULL or if an event with the specified name is not present in the
 * calendar. */
int remove_event(Calendar *calendar, const char *name) {
	Event *curr_event, *prev_event = NULL; 
	int i;

	/* FAILURE checks. */
	if(calendar == NULL || name == NULL || 
	   same_name(name, calendar->events, calendar->days, -1) == SUCCESS) {
		return FAILURE;
	}

	/* Search for event in the whole calendar with the specified name. */
	for(i = 0; i < calendar->days; i++) {
		curr_event = *(calendar->events + i);
		while(curr_event != NULL && strcmp(curr_event->name, name) 
			  != 0) {
			prev_event = curr_event;
			curr_event = curr_event->next;
		}
		if(curr_event != NULL) {
			break;
		}
		prev_event = NULL;
	}

	/* If the found event is the head, update second item to be the head.
	 * Otherwise the next element of the previous event is set to the next
	 * element of the current event, skipping over the found event. */
	if(prev_event == NULL) {
		*(calendar->events + i) = curr_event->next;
	}else {
		prev_event->next = curr_event->next;
	}
	/* Memory associated with the event is freed. The info of the event is
	 * only freed if the info field and free_info_func are not NULL, but
	 * the name and event itself are always freed. */
	if(calendar->free_info_func != NULL && curr_event->info != NULL) {
		calendar->free_info_func(curr_event->info);
	}
	free(curr_event->name);
	free(curr_event);
	calendar->total_events--;

	return SUCCESS;
}

/* Returns the info pointer associated with the specified event. The 
 * function returns NULL if the event is not found in the calendar. */
void *get_event_info(Calendar *calendar, const char *name) {
	int i;
	Event *curr_event, *prev_event = NULL;

	/* FAILURE checks. */
	if(same_name(name, calendar->events, calendar->days, -1) == SUCCESS) {
		return NULL;
	}

	/* Search for event in the whole calendar with the specified name. */
	for(i = 0; i < calendar->days; i++) {
		curr_event = *(calendar->events + i);
		while(curr_event != NULL && strcmp(curr_event->name, name) 
			  != 0) {
			prev_event = curr_event;
			curr_event = curr_event->next;
		}
		if(curr_event != NULL) {
			break;
		}
		prev_event = NULL;
	}

	return curr_event->info;
}

/* Removes every event (as specified in remove_event) and sets every event
 * list to empty. The array of pointers to event lists is not removed. 
 * If the calendar is NULL, FAILURE is returned, otherwise SUCCESS is. */
int clear_calendar(Calendar *calendar) {
	int i;

	/* FAILURE check. */
	if(calendar == NULL) {
		return FAILURE;
	}

	/* Removes all events through use of recursive list traversal. */
	for(i = 0; i < calendar->days; i++) {
		remove_all_aux(calendar, calendar->events + i);
	}

	return SUCCESS;	
}

/* Removes all the events for the specified day, setting the day's event
 * list to empty and returning SUCCESS. FAILURE is returned if calendar is 
 * NULL or if day is less than 1 or greater than the number of calendar
 * days. */
int clear_day(Calendar *calendar, int day) {
	/* FAILURE check. */
	if(calendar == NULL || day < 1 || day > calendar->days) {
		return FAILURE;
	}

	/* Removes all events in the specified day. */
	remove_all_aux(calendar, calendar->events + day - 1);

	return SUCCESS;
}

/* Removes every event (as specified in remove_event) and frees all memory
 * that was allocated for the calendar, returning SUCCESS. If calendar is
 * NULL, FAILURE is returned. */
int destroy_calendar(Calendar *calendar) {
	int i;

	/* FAILURE check. */
	if(calendar == NULL) {
		return FAILURE;
	}

	/* Removes all events through use of recursive list traversal. */
	for(i = 0; i < calendar->days; i++) {
		remove_all_aux(calendar, calendar->events + i);
	}

	/* All memory previously allocated for the calendar is deallocated. */
	free(calendar->events);
	free(calendar->name);
	free(calendar);
	return SUCCESS;
}
