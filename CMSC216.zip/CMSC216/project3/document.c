/* Name: Mohammad Sheikhattari
 * UID: 117018387
 * Directory ID: msheikha */

#include <stdio.h>
#include <string.h>

#include "document.h"


static int paragraph_space(const Document *doc,
						   char data[][MAX_STR_SIZE + 1],
						   const int data_lines);

static int line_space(char data[][MAX_STR_SIZE + 1], const int data_lines);

static int remove_text_line(Document *doc, const char *target,
                            const int paragraph, const int line);

static int replace_text_line(Document *doc, const char *target,
                             const char *replacement, const int paragraph,
                             const int line);

static int highlight_text_line(Document *doc, const char *target,
                               const int paragraph, const int line);

static int file_paragraph_space(const char *file_name, const Document *doc);

static int file_line_space(const char *file_name);

/* Helper function for load_file that checks the number of paragraphs
 * that would be added based on the number of empty lines in the file. 
 * If adding that many paragraphs violates the max number of allowed 
 * paragraphs, FAILURE is returned, otherwise SUCCESS is returned. */
static int file_paragraph_space(const char *file_name,
								const Document *doc) {
	int empties = 0;
	FILE *file = fopen(file_name, "r");
	char line[MAX_STR_SIZE + 1] = {0}, junk, *empty = &junk;
	
	fgets(line, MAX_STR_SIZE + 1, file);
	while(!feof(file)) { 
		empty = line + strlen(line) - 1;
		while(empty >= line) {
			if(!isspace(*empty)) {
				empty = NULL;
			}else {
				empty--;
			}
		}
		if(empty != NULL) {
			empties++;
		}
		fgets(line, MAX_STR_SIZE + 1, file);
	}
	fclose(file);

	if(empties > MAX_PARAGRAPHS - doc->number_of_paragraphs) {
		return FAILURE;
	}

	return SUCCESS;
}

/* Helper function for load_file that checks the number of lines that would
 * be aded to each pargraph based on the number of consecutive non-empty 
 * lines in the file. If there is ever a violation of the max number of 
 * allowed lines per paragraph, FAILURE is returned otherwise SUCCESS is
 * returned. */
static int file_line_space(const char *file_name) {
	int lines = 0;
	FILE *file = fopen(file_name, "r");
	char line[MAX_STR_SIZE + 1] = {0}, junk, *empty = &junk;

	fgets(line, MAX_STR_SIZE + 1, file);
	while(!feof(file)) {
		empty = line + strlen(line) - 1;
		while(empty >= line) {
			if(!isspace(*empty)) {
				empty = NULL;
			}else {
				empty--;
			}
		}
		if(empty == NULL) {
			lines++;
		}else {
			lines = 0;
		}
		if(lines > MAX_PARAGRAPH_LINES) {
			fclose(file);
			return FAILURE;
		}
		fgets(line, MAX_STR_SIZE + 1, file);
	}

	fclose(file);
	return SUCCESS;
}

/* Helper function for load_document that checks the number of paragraphs
 * that would be added based on the number of empty rows in the array.
 * If adding that many paragraphs violates the max number of allowed 
 * paragraphs, FAILURE is returned, otherwise SUCCESS is returned. */
static int paragraph_space(const Document *doc,
	          			   char data[][MAX_STR_SIZE + 1], 
					       const int data_lines) {
	int i, empties = 0;

	for(i = 0; i < data_lines; i++) {
		if(data[i][0] == 0) {
			empties++;
		}
	}

	if(empties > MAX_PARAGRAPHS - doc->number_of_paragraphs) {
		return FAILURE;
	}else {
		return SUCCESS;
	}
}

/* Helper function for load_document that checks the number of lines that
 * would be added to the paragraphs based on the number of consecutive 
 * non-empty rows present in the data array. If adding that many lines 
 * violates the max number of allowed lines in any paragraph, FAILURE is
 * returned, otherwise SUCCESS is returned. */
static int line_space(char data[][MAX_STR_SIZE + 1], const int data_lines) {
	int i, lines = 0;

	for(i = 0; i < data_lines; i++) {
		if(data[i][0] == 0) {
			lines = 0;
		}else {
			lines++;
		}
		if(lines > MAX_PARAGRAPH_LINES) {
		    return FAILURE;
		} 
	}
	
	return SUCCESS;	
}

/* Helper function for remove_text that remove text in a single line. */
static int remove_text_line(Document *doc, const char *target, 
         				  	const int paragraph, const int line) { 
	int new_idx = 0;
	char new_line[MAX_STR_SIZE + 1] = {0}, *cur_line = 
		 doc->paragraphs[paragraph].lines[line];

	while(*cur_line != '\0') {
		if(strstr(cur_line, target) == cur_line) {
			cur_line += strlen(target);
		}else {
			new_line[new_idx] = *cur_line;
			cur_line++;
			new_idx++;
		}
	}	

	strcpy(doc->paragraphs[paragraph].lines[line], new_line);

	return SUCCESS;
}

/* Helper function for replace_text that replaces text in a single line. */
static int replace_text_line(Document *doc, const char *target, 
					         const char *replacement, const int paragraph, 
					         const int line) { 
	int i, new_idx = 0;		
	char new_line[MAX_STR_SIZE + 1] = {0};
	char *cur_line = 
	     doc->paragraphs[paragraph].lines[line];
		 
	while(*cur_line != '\0') {	
		if(strstr(cur_line, target) == cur_line) {
			for(i = 0; i < strlen(replacement); i++) {
				new_line[new_idx] = *(replacement + i);
				new_idx++;
			}
			cur_line += strlen(target);					
		}else {												
			new_line[new_idx] = *cur_line;	
			cur_line++;	
			new_idx++;
		}  		
	}  																
	
	 strcpy(doc->paragraphs[paragraph].lines[line], new_line);		
	
	return SUCCESS;						
}

/* Helper function for highlight_text that highlights text in a single line
 * with HIGHLIGHT_START_STR and HIGHLIGHT_END_STR. */
static int highlight_text_line(Document *doc, const char *target,
                               const int paragraph, const int line) {
	int i, new_idx = 0;
	char new_line[MAX_STR_SIZE + 1] = {0}, *cur_line =
	     doc->paragraphs[paragraph].lines[line];
	 
	while(*cur_line != 0) {
		if(strstr(cur_line, target) == cur_line) {
			for(i = 0; i < strlen(HIGHLIGHT_START_STR); i++) {
				new_line[new_idx] = *(HIGHLIGHT_START_STR + i);
				new_idx++;
			}

			for(i = 0; i < strlen(target); i++) {
		   		new_line[new_idx] = *(target + i);
		    	new_idx++;
	         }

			 for(i = 0; i < strlen(HIGHLIGHT_END_STR); i++) {
				new_line[new_idx] = *(HIGHLIGHT_END_STR + i);
			 	new_idx++;
			 }
			 cur_line += strlen(target);
        }else {
		 	new_line[new_idx] = *cur_line;
			cur_line++;
        	new_idx++;
		}
	}

	strcpy(doc->paragraphs[paragraph].lines[line], new_line);
		
	return SUCCESS;
}


/* Initializes doc to have 0 paragraphs and sets its name to the name 
 * parameter. */
int init_document(Document *doc, const char *name) {
	if(doc == NULL || name == NULL || strlen(name) < 1 || strlen(name) > 
	   MAX_STR_SIZE) {
		return FAILURE;
	}

	doc->number_of_paragraphs = 0;
	strcpy(doc->name, name);
	
	return SUCCESS;
}

/* Sets the number of paragraphs to 0. */
int reset_document(Document *doc) {
	if(doc == NULL) {
		return FAILURE;
	}

	doc->number_of_paragraphs = 0;

	return SUCCESS;
}

/* Print's the document's name, number of paragraphs, followed by the 
 * paragraphs with one line between separate paragraphs.*/
int print_document(Document *doc) {
	int i, j;
	
	if(doc == NULL) {
		return FAILURE;
	}

	printf("Document name: \"%s\"\n", doc->name);
	printf("Number of Paragraphs: %d\n", doc->number_of_paragraphs);
	
	for(i = 0; i < doc->number_of_paragraphs; i++) {
		for(j = 0; j < doc->paragraphs[i].number_of_lines; j++) {
			printf("%s\n", doc->paragraphs[i].lines[j]);	
		}
		if(doc->number_of_paragraphs > 1 && i != doc->number_of_paragraphs
		   - 1) {		
			printf("\n");
		}
	}	
	return SUCCESS;
}

/* Adds a paragraph after the specified paragraph number and shifts the 
 * other paragraphs to accommodate.*/
int add_paragraph_after(Document *doc, int paragraph_number) {
	int i;
	Paragraph paragraphs[MAX_PARAGRAPHS];

	if(doc == NULL || doc->number_of_paragraphs >= MAX_PARAGRAPHS ||
	   paragraph_number < 0 ||
	   paragraph_number > doc->number_of_paragraphs) {
		return FAILURE;
	}

	for(i = 0; i <= doc->number_of_paragraphs; i++) {
		if(i < paragraph_number) {
			paragraphs[i] = doc->paragraphs[i];
		}else if(i == paragraph_number) {
			paragraphs[i].number_of_lines = 0;	
		}else if(i > paragraph_number) {
			paragraphs[i] = doc->paragraphs[i - 1];
		}
	}
	for(i = 0; i <= doc->number_of_paragraphs; i++) {
		doc->paragraphs[i] = paragraphs[i];
	}

	doc->number_of_paragraphs++;
	
	return SUCCESS;
}

/* Adds new_line to after the specified line number in the paragraph
 * specified. Shifts the other lines to accommodate.*/
int add_line_after(Document *doc, int paragraph_number, int line_number,
				   const char *new_line) {
	int i;
	char lines[MAX_PARAGRAPH_LINES][MAX_STR_SIZE + 1];
	
	if(doc == NULL || paragraph_number > doc->number_of_paragraphs ||
       doc->paragraphs[paragraph_number - 1].number_of_lines >=
	   MAX_PARAGRAPH_LINES || line_number < 0 || line_number > 
	   doc->paragraphs[paragraph_number - 1].number_of_lines ||
	   new_line == NULL) {
		return FAILURE;
	}
	for(i = 0; i <= doc->paragraphs[paragraph_number - 1].number_of_lines;
		i++) {
 		if(i < line_number) {
	  		strcpy(lines[i], doc->paragraphs[paragraph_number - 1].
				   lines[i]);
		}else if(i == line_number) {
			strcpy(lines[i], new_line);
		}else if(i > line_number) {
			strcpy(lines[i], doc->paragraphs[paragraph_number - 1].
				   lines[i - 1]);
		}
	}
	for(i = 0; i <= doc->paragraphs[paragraph_number - 1].number_of_lines;
		i++) {
		strcpy(doc->paragraphs[paragraph_number - 1].lines[i], lines[i]);
	}

	doc->paragraphs[paragraph_number - 1].number_of_lines++;

	return SUCCESS;
}

/* Returns the number of lines in a specified paragraph by assigning it to
 * number_of_lines. */
int get_number_lines_paragraph(Document *doc, int paragraph_number, 
							   int *number_of_lines) {
	if(doc == NULL || number_of_lines == NULL || paragraph_number >
	   doc->number_of_paragraphs) {
		return FAILURE;
	}

	*number_of_lines = doc->paragraphs[paragraph_number - 1].
					   number_of_lines;

	return SUCCESS;
}

/* Adds new_line to the end of the specified paragraph. */
int append_line(Document *doc, int paragraph_number, const char *new_line) {
	int line_idx;

	if(doc == NULL || paragraph_number > doc->number_of_paragraphs ||
	   doc->paragraphs[paragraph_number - 1].number_of_lines >=
	   MAX_PARAGRAPH_LINES || new_line == NULL) {
		return FAILURE;
	}
	line_idx = doc->paragraphs[paragraph_number - 1].number_of_lines;
	strcpy(doc->paragraphs[paragraph_number - 1].lines[line_idx], new_line);
	doc->paragraphs[paragraph_number - 1].number_of_lines++;

	return SUCCESS;
}

/* Removes the specified line from the specified paragraph. Shifts the other
 * lines to accommodate. */
int remove_line(Document *doc, int paragraph_number, int line_number) {
	int i;
	char lines[MAX_PARAGRAPH_LINES][MAX_STR_SIZE + 1];

	if(doc == NULL || paragraph_number > doc->number_of_paragraphs || 
	   line_number > doc->paragraphs[paragraph_number - 1].
	   number_of_lines) {
		return FAILURE;
	}
	for(i = 0; i < doc->paragraphs[paragraph_number - 1].number_of_lines;
		i++) {
		if(i < line_number - 1) {
			strcpy(lines[i], doc->paragraphs[paragraph_number - 1].
			lines[i]);	
		}else if(i > line_number - 1) {
			strcpy(lines[i - 1], doc->paragraphs[paragraph_number - 1].
			lines[i]);
		}
	}
	for(i = 0; i < doc->paragraphs[paragraph_number - 1].number_of_lines;
		i++) {
		strcpy(doc->paragraphs[paragraph_number - 1].lines[i], lines[i]);
	}
	for(i = 0; i < MAX_STR_SIZE; i++){
		doc->paragraphs[paragraph_number - 1].
		lines[doc->paragraphs[paragraph_number - 1].number_of_lines][i] = 0;
	}
	doc->paragraphs[paragraph_number - 1].number_of_lines--;

	return SUCCESS;
}

/* Adds the first data_lines number of rows from the data array to the 
 * document, starting a new paragraph at the beginning of the document. A 
 * row with an empty string starts a new paragraph. */
int load_document(Document *doc, char data[][MAX_STR_SIZE + 1],
				  int data_lines) {
	int i, cur_paragraph = 1, cur_line = 0;

	if(doc == NULL || data == NULL || data_lines == 0 || 
	   paragraph_space(doc, data, data_lines) == FAILURE ||
	   line_space(data, data_lines) == FAILURE) {
	    return FAILURE;
	}

	add_paragraph_after(doc, 0);
	for(i = 0; i < data_lines; i++) { 
		if(data[i][0] == 0) {
			add_paragraph_after(doc, cur_paragraph);
			cur_paragraph++;
			cur_line = 0;
		}else {
			add_line_after(doc, cur_paragraph, cur_line, data[i]);
			cur_line++;
		}
	}

	return SUCCESS;
}

/* Replaces every instance of the text target in the document with the text 
 * replacement. */
int replace_text(Document *doc, const char *target,
				 const char *replacement) {
	int i, j;
	Paragraph paragraph;

	if(doc == NULL || target == NULL || replacement == NULL) {
		return FAILURE;
	}

	for(i = 0; i < doc->number_of_paragraphs; i++) {
		paragraph = doc->paragraphs[i];
		for(j = 0; j < paragraph.number_of_lines; j++) {
			replace_text_line(doc, target, replacement, i, j);
		}
	}
	
	return SUCCESS;
}

/* Highlights every instance of the text target in the document by 
 * surrounding it with HIGHLIGHT_START_STR and HIGHLIGHT_END_STR. */
int highlight_text(Document *doc, const char *target) {
	int i, j;
	Paragraph paragraph;

	if(doc == NULL || target == NULL) {
		return FAILURE;
	}

	for(i = 0; i < doc->number_of_paragraphs; i++) {
		paragraph = doc->paragraphs[i];
		for(j = 0; j < paragraph.number_of_lines; j++) {
			highlight_text_line(doc, target, i, j);
		}
	}

	return SUCCESS;
}

/* Removes every instance of the text target from the document. */
int remove_text(Document *doc, const char *target) {
	int i, j;
	Paragraph paragraph;

	if(doc == NULL || target == NULL) {
		return FAILURE;
	}

	for(i = 0; i < doc->number_of_paragraphs; i++) {
		paragraph = doc->paragraphs[i];
		for(j = 0; j < paragraph.number_of_lines; j++) {
			remove_text_line(doc, target, i, j);	
		}
	}

	return SUCCESS;
}

/* Similar to load_doc, except the data is loaded from a file rather than
 * an array. */
int load_file(Document *doc, const char *filename) {
	char line[MAX_STR_SIZE + 1] = {0}, *empty;
	int cur_paragraph = 1, cur_line = 0;
	FILE *input;

	/* Checks that parameters are valid and the doc has space to add the
	 * file. */
	if(doc == NULL || filename == NULL || 
	   file_line_space(filename) == FAILURE ||
	   file_paragraph_space(filename, doc) == FAILURE ||
	   (input = fopen(filename, "r")) == NULL) { 
		return FAILURE;
	}

	add_paragraph_after(doc, 0);
	/* Might need to change arg2 based on allowed size... */
	while(fgets(line, MAX_STR_SIZE, input) != NULL) {
		empty = line + strlen(line) - 1;	
		while(empty >= line) {
			if(!isspace(*empty)) {
				line[strlen(line) - 1] = 0;
				add_line_after(doc, cur_paragraph, cur_line, line);
				cur_line++;
				empty = NULL;
			}else {
				empty--;
			}
		}
		if(empty != NULL) {
			add_paragraph_after(doc, cur_paragraph);
			cur_paragraph++;
			cur_line = 0;
		}
	}
	fclose(input);

	return SUCCESS;
}

/* Saves the document to the specified file, with the same format as 
 * print_document. */
int save_document(Document *doc, const char *filename) {
	int i, j;
	FILE *input;

	if(doc == NULL || filename == NULL ||
	   (input = fopen(filename , "w")) == NULL) {
		return FAILURE;
	}

	for(i = 0; i < doc->number_of_paragraphs; i++) {
		for(j = 0; j < doc->paragraphs[i].number_of_lines; j++) {
			fputs(doc->paragraphs[i].lines[j], input);
			fputs("\n", input);
		}
		if(doc->number_of_paragraphs > 1 && i != doc->number_of_paragraphs 
		   - 1) {
		   	fputs("\n", input);
		}
	}	

	return SUCCESS;
}
