#include <stdio.h>
#include <stdlib.h>
#include "document.h"

int main() {
  system("./user_interface public04.in");

  return 0;
}
