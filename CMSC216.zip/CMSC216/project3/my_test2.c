add_paragraph_after 0
append_line 1 *cancer
print_document
load_file aids
