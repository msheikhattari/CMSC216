/* Name: Mohammad Sheikhattari
 * UID: 117018387
 * Directory ID: msheikha */

#include <stdio.h>
#include <string.h>
#include <sysexits.h>
#include <stdlib.h>
#include <ctype.h>
#include "document.h"

#define COMMAND 1
#define MAX_COMMAND_LEN 1024

static int line_type(char *line);

static int process_line(char *line, Document *doc, int *quit);

/* Helper function to determine if a line is valid. If it is not, "Invalid
 * Command" is printed to standard output and FAILURE is returned, otherwise
 * COMMAND is returned if it is specifically a command line and SUCCESS if
 * it is just a comment or blank line. */
static int line_type(char *line) {
	char *hash, *empty = line + strlen(line) - 1;	

	/* Check for comment line. Hash location is found in string if it
	 * exists, then we make sure it's truly the first non-whitespace that
	 * appears. */
	hash = strchr(line, '#');
	if(hash != NULL) {
		hash--;
		while(hash >= line) {
			if(!isspace(*hash)) {
				printf("Invalid Command\n");
				return FAILURE;
			}
			hash--;
		}
		return SUCCESS;
	}

	/* Check for command line. If any of the strings below are found in the
	 * input line it is a command line. */
	if(strstr(line, "add_paragraph_after") ||
	   strstr(line, "add_line_after") || strstr(line, "print_document") ||
	   strstr(line, "quit") || strstr(line, "exit") || 
	   strstr(line, "append_line") || strstr(line, "remove_line") ||
	   strstr(line, "load_file") || strstr(line, "replace_text") ||
	   strstr(line, "highlight_text") || strstr(line, "remove_text") || 
	   strstr(line, "save_document") || strstr(line, "reset_document")) {
		return COMMAND;
	}

	/* Check for blank line. Starting from the front of the string, if there
	 * are only whitespaces all the way back through the beginning of the
	 * string, it is a blank line. */
	while(empty >= line) {
		if(!isspace(*empty)) {
			printf("Invalid Command\n");
			return FAILURE;
		}
		empty--;
	}
		
	return SUCCESS;
}

/* Helper function to convert each command line into document.c function 
 * calls. Each command is given a separate treatment, and has conditions
 * under which the command will tell user the command is provided in an
 * invalid format, or if it was in a valid format it will tell the user
 * if the command did not execute sucessfully. */
static int process_line(char *line, Document *doc, int *quit) {
	int paragraph_number = -1, line_number = -1, text_idx = 0;
	char *line_ptr = NULL, decoy[MAX_COMMAND_LEN + 1],
		 doc_line[MAX_STR_SIZE + 1] = {0}, file_name[MAX_COMMAND_LEN + 1] =
		 {0}, target[MAX_STR_SIZE + 1] = {0}, replacement[MAX_STR_SIZE + 1]
		 = {0}, junk, *target_and_replacement = &junk;

	if(line_type(line) == COMMAND) {
		if((line_ptr = strstr(line, "add_paragraph_after"))) {
			if(sscanf(line_ptr, "add_paragraph_after %d %s", 
			&paragraph_number, decoy) == 1 && paragraph_number >= 0) {
				if(add_paragraph_after(doc, paragraph_number) == FAILURE) {
					printf("add_paragraph_after failed\n");
				}
			}else {
				printf("Invalid Command\n");
			}
		}else if((line_ptr = strstr(line, "add_line_after"))) {
			if(sscanf(line_ptr, "add_line_after %d %d %s",
			   &paragraph_number, &line_number, decoy) == 3 && 
			   paragraph_number > 0 && line_number >= 0 && decoy[0] == 
			   '*') {
				strcpy(doc_line, strchr(line_ptr, '*'));
				doc_line[strlen(doc_line) - 1] = 0;
				if(add_line_after(doc, paragraph_number, line_number,
				   doc_line + 1) == FAILURE) {
					printf("add_line_after failed\n");
				}
			}else {
				printf("Invalid Command\n");
			}
		}else if((line_ptr = strstr(line, "print_document"))) {
			if(sscanf(line_ptr, "print_document %s", decoy) != EOF) {
				printf("Invalid Command\n");
			}else {
				print_document(doc);
			}
		}else if((line_ptr = strstr(line, "quit"))) {
			if(sscanf(line_ptr, "quit %s", decoy) != EOF) {
				printf("Invalid Command\n");
			}else {
				*quit = 1;
			}
		}else if((line_ptr = strstr(line, "exit"))) {
			if(sscanf(line_ptr, "exit %s", decoy) != EOF) {
				printf("Invalid Command\n");
			}else {
				*quit = 1;
			}
		}else if((line_ptr = strstr(line, "append_line"))) {
			if(sscanf(line_ptr, "append_line %d %s", &paragraph_number,
			   decoy) == 2 && paragraph_number > 0 && decoy[0] == '*') {
				strcpy(doc_line, strchr(line_ptr, '*'));
				doc_line[strlen(doc_line) - 1] = 0;
				if(append_line(doc, paragraph_number, doc_line + 1) == 
				   FAILURE) {
					printf("append_line failed\n");
				}
			}else {
				printf("Invalid Command\n");
			}
		}else if((line_ptr = strstr(line, "remove_line"))) {
			if(sscanf(line_ptr, "remove_line %d %d %s", &paragraph_number, 
			   &line_number, decoy) == 2 && paragraph_number > 0 &&
			   line_number > 0) {
				if(remove_line(doc, paragraph_number, line_number) == 
				   FAILURE) {
					printf("remove_line failed\n");
				}
			}else {
				printf("Invalid Command\n");
			}
		}else if((line_ptr = strstr(line, "load_file"))) {
			if(sscanf(line_ptr, "load_file %s %s", file_name, decoy) == 1 
			&& file_name[0] != 0) {
				if(load_file(doc, file_name) == FAILURE) {
					printf("load_file failed\n");
				}
			}else {
				printf("Invalid Command\n");
			}
		}else if((line_ptr = strstr(line, "replace_text"))) {
			if(sscanf(line, "replace_text %s", decoy) == EOF) {
				printf("Invalid Command\n");
			}else {
				target_and_replacement = strchr(line, '\"') + 1;
				while(*target_and_replacement != '\"') {
					target[text_idx] = *target_and_replacement;
					text_idx++;
					target_and_replacement++;
				}
				target_and_replacement++;
				if((target_and_replacement = strchr(target_and_replacement,
				   '\"')) == NULL) {
					printf("Invalid Command\n");
				}else {
					text_idx = 0;
					target_and_replacement++;
					while(*target_and_replacement != '\"') {
						replacement[text_idx] = *target_and_replacement;
						text_idx++;
						target_and_replacement++;
					}
					if(replace_text(doc, target, replacement) == FAILURE) {
						printf("replace_text failed\n");
					}
				}
			}
		}else if((line_ptr = strstr(line, "highlight_text"))) {
			if(sscanf(line_ptr, "highlight_text %s", decoy) == EOF) {
				printf("Invalid Command\n");
			}else {
				strcpy(target, strchr(line, '\"') + 1);
				target[strlen(target) - 1] = 0;
				target[strlen(target) - 1] = 0;
				highlight_text(doc, target);
			}
		}else if((line_ptr = strstr(line, "remove_text"))) {
			if(sscanf(line_ptr, "remove_text %s", decoy) == EOF) {
				printf("Invalid Command\n");
			}else {
				strcpy(target, strchr(line, '\"') + 1);
				target[strlen(target) - 1] = 0;
				target[strlen(target) - 1] = 0;
				remove_text(doc, target);
			}
		}else if((line_ptr = strstr(line, "save_document"))) {
			if(sscanf(line_ptr, "save_document %s %s", file_name, decoy) 
			   == 1) {
				if(save_document(doc, file_name) == FAILURE) {
					printf("save_document failed\n");
				}
			}else {
				printf("Invalid Command\n");
			}
		}else if((line_ptr = strstr(line, "reset_document"))) {
			if(sscanf(line_ptr, "reset_document %s", decoy) == EOF) {
				reset_document(doc);
			}else {
				printf("Invalid Command\n");
			}
		}
	}

	return SUCCESS;
}


/* Reads data either from standard input or a provided file in order to 
 * perform operations on a newly created document. If there is more than
 * one argument after the executable a usage error is printed to stderr. */
int main(int argc, char *argv[]) {
	Document doc;
	FILE *input;
	char line[MAX_COMMAND_LEN + 1] = {0};
	int quit = 0;

	if(argc > 2) {
		fprintf(stderr, "Usage: user_interface\n"
			   "Usage: user_interface <filename>\n");
		exit(EX_USAGE);
	}else if(argc == 2) {
		if((input = fopen(argv[1], "r")) == NULL) {
			fprintf(stderr, "%s cannot be opened.\n", argv[1]);
			exit(EX_OSERR);
		}
	}else {
		input = stdin;
	}
	init_document(&doc, "main_document");
	
	while(!feof(input) && !quit) {
		if(input == stdin) {
			printf("> ");
		}
		if (fgets(line, MAX_COMMAND_LEN + 1, input) != NULL) {		
			process_line(line, &doc, &quit);
		}	
	}

	return SUCCESS;
}
