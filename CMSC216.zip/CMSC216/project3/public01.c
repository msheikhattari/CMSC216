#include <stdio.h>
#include <stdlib.h>
#include "document.h"

int main() {
  /* Run user_interface with input on stdin */
  system("./user_interface < public01.in");

  return 0;
}
