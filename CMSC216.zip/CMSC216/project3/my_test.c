#include <stdio.h>
#include <string.h>
#include "document.h"

int file_line_space(const char *file_name, const Document *doc);

int line_space(char data[][MAX_STR_SIZE + 1], const int data_lines);

int main() {
    Document doc;
    const char *doc_name = "Exercise Description"; 
		 
	char data[30][MAX_STR_SIZE + 1] = { {'\t', '1'}, {'2'}, {'3'}, {'4'}, {'5'},
									    {'1'}, {'2'}, {'3'}, {'4'}, {'5'},
										{'1'}, {'2'}, {'3'}, {'4'}, {'5'},
										{'1'}, {'2'}, {'3'}, {'4'}, {'5'},
										{'6'}};

    init_document(&doc, doc_name);
	/*load_file(&doc, "doc1.txt");
	*/save_document(&doc, "out.txt");

    replace_text(&doc, " a", "new");

	/*load_document(&doc, data, 10);
*/
	load_document(&doc, data, 30);
	printf("%d\n", line_space(data, 30));
	print_document(&doc);
   
   	

	return SUCCESS;
}
