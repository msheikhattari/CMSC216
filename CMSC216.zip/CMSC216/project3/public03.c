#include <stdio.h>
#include <stdlib.h>
#include "document.h"

int main() {
  system("./user_interface public03.in");

  return 0;
}
