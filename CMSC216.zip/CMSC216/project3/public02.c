#include <stdio.h>
#include <stdlib.h>
#include "document.h"

int main() {
  system("./user_interface public02.in");

  return 0;
}
